package com.example.noortimes

import android.content.Context
import android.content.Context.MODE_PRIVATE

object Prefs {
    private const val FILE = "noortimes_prefs"
    private const val KEY_LOGGED_IN = "is_logged_in"

    fun isLoggedIn(ctx: Context): Boolean =
        ctx.getSharedPreferences(FILE, MODE_PRIVATE)
            .getBoolean(KEY_LOGGED_IN, false)

    fun setLoggedIn(ctx: Context, value: Boolean) {
        ctx.getSharedPreferences(FILE, MODE_PRIVATE)
            .edit().putBoolean(KEY_LOGGED_IN, value).apply()
    }

    fun logOut(ctx: Context) = setLoggedIn(ctx, false)
}
