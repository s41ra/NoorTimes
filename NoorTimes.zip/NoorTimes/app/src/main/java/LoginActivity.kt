package com.example.noortimes

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)  // uses your activity_login.xml

        val etUser = findViewById<EditText>(R.id.etUsername)
        val etPass = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<MaterialButton>(R.id.btnLogin)
        val linkSignUp = findViewById<TextView>(R.id.linkSignUp)
        val btnForgot = findViewById<TextView>(R.id.btnForgot)

        // Navigate to SignUp
        linkSignUp.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }

        // Stub forgot password
        btnForgot.setOnClickListener {
            Toast.makeText(this, "Forgot password clicked", Toast.LENGTH_SHORT).show()
        }

        // Fake login -> go to MainActivity
        btnLogin.setOnClickListener {
            val u = etUser.text?.toString()?.trim().orEmpty()
            val p = etPass.text?.toString()?.trim().orEmpty()
            if (u.isEmpty()) { etUser.error = "Required"; return@setOnClickListener }
            if (p.isEmpty()) { etPass.error = "Required"; return@setOnClickListener }

            startActivity(Intent(this, MainActivity::class.java))
            finish() // don’t come back to login with back button
        }
    }
}
