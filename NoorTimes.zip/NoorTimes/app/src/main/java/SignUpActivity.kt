package com.example.noortimes

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.checkbox.MaterialCheckBox

class SignUpActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        val etFirst = findViewById<EditText>(R.id.etFirstName)
        val etLast = findViewById<EditText>(R.id.etLastName)
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPass = findViewById<EditText>(R.id.etPassword)
        val etConfirm = findViewById<EditText>(R.id.etConfirmPassword)
        val cbTerms = findViewById<MaterialCheckBox>(R.id.cbTerms)
        val tvTerms = findViewById<TextView>(R.id.tvTerms)
        val btnSignUp = findViewById<Button>(R.id.btnSignUp)
        val tvLoginHere = findViewById<TextView>(R.id.tvLoginHere)

        // Clickable "Terms of Use" & "Privacy Policy"
        makeTermsClickable(tvTerms,
            termsUrl = "https://example.com/terms",
            privacyUrl = "https://example.com/privacy"
        )

        // "Login here" link -> back to LoginActivity
        tvLoginHere.movementMethod = LinkMovementMethod.getInstance()
        tvLoginHere.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        // Simple validation example
        btnSignUp.setOnClickListener {
            when {
                etFirst.text.isNullOrBlank() -> etFirst.error = "First name required"
                etLast.text.isNullOrBlank() -> etLast.error = "Last name required"
                etEmail.text.isNullOrBlank() -> etEmail.error = "Email required"
                etPass.text.isNullOrBlank() -> etPass.error = "Password required"
                etConfirm.text.toString() != etPass.text.toString() -> etConfirm.error = "Passwords do not match"
                !cbTerms.isChecked -> toast("Please accept the Terms to continue")
                else -> toast("Signed up! (stub)")
            }
        }
    }

    private fun makeTermsClickable(textView: TextView, termsUrl: String, privacyUrl: String) {
        val src = getString(R.string.accept_terms_full)
        val ss = SpannableString(src)

        val terms = "Terms of Use"
        val privacy = "Privacy Policy"

        val termsStart = src.indexOf(terms)
        val privacyStart = src.indexOf(privacy)

        if (termsStart >= 0) {
            ss.setSpan(object : ClickableSpan() {
                override fun onClick(widget: View) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(termsUrl)))
                }
            }, termsStart, termsStart + terms.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (privacyStart >= 0) {
            ss.setSpan(object : ClickableSpan() {
                override fun onClick(widget: View) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(privacyUrl)))
                }
            }, privacyStart, privacyStart + privacy.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        textView.text = ss
        textView.movementMethod = LinkMovementMethod.getInstance()
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
