package com.example.noortimes

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class EntryActivity : AppCompatActivity() {

    private val splashMillis = 1500L   // 1.5s welcome screen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // If already authenticated, go straight to Main
        if (Prefs.isLoggedIn(this)) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        // Show the welcome splash
        setContentView(R.layout.activity_entry_welcome)

        // Tap anywhere to continue immediately
        findViewById<View>(android.R.id.content).setOnClickListener {
            goNext()
        }

        // Or auto-continue after a short delay
        Handler(Looper.getMainLooper()).postDelayed({ goNext() }, splashMillis)
    }

    private fun goNext() {
        // default flow → Login first
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
